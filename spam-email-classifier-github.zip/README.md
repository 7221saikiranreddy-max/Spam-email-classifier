# Spam Email Classifier

A machine learning & transformer-based project to detect spam emails automatically, reducing inbox clutter and phishing risks.

## Features
- Text preprocessing: cleaning, tokenization, stopword removal, URL/HTML handling
- Feature extraction: TF–IDF n-grams, header/metadata signals
- Models: Multinomial Naive Bayes, Logistic Regression, BERT fine-tuning
- Evaluation: Precision, Recall, F1-score, ROC-AUC, Confusion Matrix
- Deployment-ready: Saved models for inference using joblib or Hugging Face Transformers

## Dataset
- Public datasets like Enron Email Dataset, SpamAssassin, or Kaggle spam/ham CSV files

## Usage (baseline classical ML)
```bash
python spam_classifier_baseline.py
```

## Usage (transformer-based)
```bash
python spam_transformer_finetune.py
```

## Results
- Classical ML (TF–IDF + Naive Bayes): ~95–98% F1-score
- Transformer (BERT fine-tuned): ~98–99% F1-score
